#!/usr/bin/env node
/**
 * #37 — Integrated explore × Jev-Mem behavioral suite
 *
 * UX / state intent:
 *  - IJ-1: Empty-graph explore Read must automatically persist the source,
 *    extracted file-path entities, and a nonzero vector linked to the observation.
 *  - IJ-2: Duplicate MAP Read is harness-rejected (already read) and must NOT create a
 *    second observation for the same path.
 *  - IJ-3: When the graph is already sufficient for the task, explore must bypass disk
 *    tools (graph-first) and still hand off out of explore.
 *  - IJ-4: Request 21 is blocked after 20 explore model requests; saturation
 *    records the reason and pins the discovered-file digest before diagnose.
 *
 * These assert production harness + real lib/jev_*.mjs — not local API redefinitions.
 * Expected RED until explore loop wires ingest / sufficiency stop / pinned pack.
 */
import assert from 'node:assert'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { openStore, closeStore, upsertPinnedContext, getPinnedContextBlocks } from '../../lib/store.mjs'
import { getPhase } from '../../lib/workflow.mjs'
import { runUserTurn } from '../../lib/orchestrate.mjs'
import { executeBuiltinTool } from '../../lib/tools.mjs'
import { ingestObservation } from '../../lib/jev_write.mjs'
import { retrieveEvidence } from '../../lib/jev_read.mjs'
import { setLayaPredictOverride, clearLayaPredictOverride, assessEvidence } from '../../lib/laya.mjs'
import {
  startMockLlmServer,
  makeOpenAiToolCallChunks,
  makeOpenAiTextChunks,
} from '../fixtures/mockLlmServer.mjs'

const layaOverride = {
  answers: {
    task_status: { choice: 'investigating', confidence: 0.9 },
    escalation_risk: { noul: 0.1 },
    episodic: { noul: 0.6 }, semantic: { noul: 0.7 }, procedural: { noul: 0.4 }, preference: { noul: 0.1 },
    need_semantic: { noul: 0.8 }, need_temporal: { noul: 0.3 }, need_causal: { noul: 0.3 }, need_entity: { noul: 0.5 },
    multi_hop: { noul: 0.2 }, recency_important: { noul: 0.7 },
    sufficient: { noul: 0.95 }, further_utility: { noul: 0.05 }, missing_required: { noul: 0.05 }, contradiction: { noul: 0.02 },
    relevance: { noul: 0.9 }, relation_useful: { noul: 0.7 }, novelty: { noul: 0.4 }, supports_evidence: { noul: 0.8 },
    semantic_related: { noul: 0.7 }, causal_influence: { noul: 0.3 }, same_episode: { noul: 0.6 }, entity_equivalent: { noul: 0.8 },
  },
}

setLayaPredictOverride(async () => layaOverride)

function countMemoriesForPath(db, pathFrag) {
  const rows = db.prepare(`SELECT entities_json, content, title FROM memories`).all()
  return rows.filter((r) => {
    const blob = `${r.entities_json || ''} ${r.content || ''} ${r.title || ''}`
    return blob.includes(pathFrag)
  }).length
}

/**
 * IJ-1 embedding evidence is intentionally storage-agnostic: the acceptance
 * contract requires a persisted numeric vector linked to the new observation,
 * but neither schema.sql nor jev_write.mjs currently defines a vector store.
 * Discover the production schema rather than assume a future table name.
 * An index definition, model name, vector dimension, or unlinked vector does
 * NOT satisfy this assertion.
 */
function numericEmbedding(value) {
  let v = value
  if (typeof v === 'string') {
    try { v = JSON.parse(v) } catch { return null }
  }
  if (Buffer.isBuffer(v)) {
    // Both F32 and F64 are common SQLite vector BLOB encodings.
    const valid = (width, read) => {
      if (v.length < width * 8 || v.length % width !== 0) return null
      const numbers = Array.from({ length: v.length / width }, (_, i) => read(i * width))
      return numbers.every(Number.isFinite) && numbers.some(n => n !== 0) ? numbers : null
    }
    return valid(4, offset => v.readFloatLE(offset)) || valid(8, offset => v.readDoubleLE(offset))
  }
  if (Array.isArray(v)) {
    if (v.length < 8 || !v.every(n => typeof n === 'number' && Number.isFinite(n))) return null
    return v.some(n => n !== 0) ? v : null
  }
  if (v && typeof v === 'object') {
    for (const key of ['embedding', 'vector', 'values', 'data']) {
      if (Object.hasOwn(v, key)) {
        const nested = numericEmbedding(v[key])
        if (nested) return nested
      }
    }
  }
  return null
}

function findPersistedObservationEmbedding(db, memoryId) {
  const tables = db.prepare(`
    SELECT name FROM sqlite_master
    WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
  `).all().map(r => r.name)

  for (const table of tables) {
    const quoted = '"' + table.replaceAll('"', '""') + '"'
    const columns = db.prepare(`PRAGMA table_info(${quoted})`).all().map(r => r.name)
    const vectorColumns = columns.filter(name =>
      /(?:^|_)(?:embedding|vector)(?:$|_)/i.test(name) &&
      !/(?:_id|_model|_dimensions?|_index|_status|_source)$/i.test(name)
    )
    if (!vectorColumns.length) continue

    // Never accept a vector belonging to some other memory. The observation
    // row itself, or a table with a foreign key to this exact ID, must own it.
    const links = table === 'memories'
      ? ['id']
      : ['memory_id', 'node_id', 'observation_id', 'mem_id', 'source_memory_id', 'id']
    const linkColumn = links.find(name => columns.includes(name))
    if (!linkColumn) continue
    const quotedLink = '"' + linkColumn.replaceAll('"', '""') + '"'
    const rows = db.prepare(`SELECT * FROM ${quoted} WHERE ${quotedLink} = ?`).all(memoryId)
    for (const row of rows) {
      for (const column of vectorColumns) {
        const vector = numericEmbedding(row[column])
        if (vector) return { table, column, dimensions: vector.length }
      }
    }
  }
  return null
}

const io = { println() {}, write() {}, ask: async () => 'y', spinner: null }

let passed = 0
let failed = 0
async function test(name, fn) {
  try {
    await fn()
    console.log(`✓ ${name}`)
    passed++
  } catch (err) {
    console.log(`✗ ${name}`)
    console.log(`  ${err?.stack || err}`)
    failed++
  }
}

await test('IJ-1: explore Read automatically persists source, extracted entities, and its embedding', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ij1-'))
  const dbPath = path.join(dir, 't.db')
  const db = openStore(dbPath)
  const cid = 'c-ij1'
  const sid = 's-ij1'
  const sourceText = '# MAP\nrouter: src/index.mjs\nhealth: lib/router/health.mjs\n'

  try {
    fs.writeFileSync(path.join(dir, 'MAP.md'), sourceText, 'utf8')
    db.prepare(`INSERT INTO conversations(id, project_dir, phase) VALUES (?,?,?)`).run(cid, dir, 'explore')
    db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES (?,?)`).run(sid, cid)

    const before = db.prepare(`SELECT COUNT(*) AS n FROM memories WHERE session_id = ?`).get(sid).n
    // Exercise production Read ingress directly. IJ-1 must not call
    // ingestObservation(), extractEntities(), or an embedding writer.
    const result = await executeBuiltinTool(
      db,
      { cwd: dir, conversationId: cid, sessionId: sid, settings: {} },
      'Read',
      { file_path: 'MAP.md' },
      io
    )
    assert.equal(result.is_error, false, 'IJ-1 precondition: production MAP.md Read must succeed')

    const observations = db.prepare(`
      SELECT id, type, session_id, conversation_id, title, content,
             entities_json, provenance, observation_ts
      FROM memories WHERE session_id = ? AND conversation_id = ? AND type = 'jev_observation'
      ORDER BY observation_ts DESC
    `).all(sid, cid)
    assert.equal(
      observations.length,
      1,
      `IJ-1: exactly one automatic observation must be persisted by the successful Read; got ${observations.length}`
    )
    assert.equal(
      db.prepare(`SELECT COUNT(*) AS n FROM memories WHERE session_id = ?`).get(sid).n,
      before + 1,
      'IJ-1: exactly one new memory must exist after one successful Read'
    )

    const observation = observations[0]
    assert.equal(observation.session_id, sid, 'IJ-1: session ownership must match')
    assert.equal(observation.conversation_id, cid, 'IJ-1: conversation ownership must match')
    assert.ok(Number.isFinite(observation.observation_ts), 'IJ-1: ingestion timestamp must be recorded')
    assert.ok(
      `${observation.title || ''} ${observation.content || ''} ${observation.entities_json || ''}`.includes('MAP.md'),
      'IJ-1: observation must identify the actual MAP.md source'
    )
    for (const line of ['router: src/index.mjs', 'health: lib/router/health.mjs']) {
      assert.ok(
        String(observation.content || '').includes(line),
        `IJ-1: persisted observation must retain actual source evidence: ${line}`
      )
    }

    let entities
    assert.doesNotThrow(() => { entities = JSON.parse(observation.entities_json) },
      'IJ-1: entities_json must contain valid JSON')
    assert.ok(Array.isArray(entities), 'IJ-1: extracted entities must be an array')
    for (const entity of ['MAP.md', 'src/index.mjs', 'lib/router/health.mjs']) {
      assert.ok(
        entities.includes(entity),
        `IJ-1: automatically extracted entities must include ${entity}; got ${JSON.stringify(entities)}`
      )
    }
    assert.equal(new Set(entities).size, entities.length, 'IJ-1: extracted entities must be deduplicated')

    const embedding = findPersistedObservationEmbedding(db, observation.id)
    assert.ok(
      embedding,
      'IJ-1: automatic ingestion must persist a finite nonzero embedding (>=8 dimensions) ' +
      'linked to the exact new observation ID. No qualifying vector exists in the SQLite ' +
      'schema/data; a source path, entities_json, or an unlinked vector is not embedding evidence.'
    )
  } finally {
    closeStore(dbPath)
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

await test('IJ-2: duplicate MAP Read does not create a second Jev observation', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ij2-'))
  const dbPath = path.join(dir, 't.db')
  const db = openStore(dbPath)
  const cid = 'c-ij2'
  const sid = 's-ij2'
  fs.writeFileSync(path.join(dir, 'MAP.md'), '# MAP\nrouter: src/index.mjs\n', 'utf8')
  db.prepare(`INSERT INTO conversations(id, project_dir, phase) VALUES (?,?,?)`).run(cid, dir, 'explore')
  db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES (?,?)`).run(sid, cid)
  const ctx = { cwd: dir, conversationId: cid, sessionId: sid, settings: {} }

  const beforeFirst = countMemoriesForPath(db, 'MAP.md')
  assert.equal(beforeFirst, 0, `precondition: expected zero MAP memories before first Read, got ${beforeFirst}`)

  const first = await executeBuiltinTool(db, ctx, 'Read', { file_path: 'MAP.md' }, io)
  assert.equal(first.is_error, false, 'first MAP read must succeed')

  const firstRows = db.prepare(`SELECT id, content, entities_json, title FROM memories WHERE session_id = ?`).all(sid)
    .filter((r) => `${r.entities_json || ''} ${r.content || ''} ${r.title || ''}`.includes('MAP.md'))
  const firstIds = firstRows.map((r) => r.id).sort()
  const firstCount = firstRows.length
  const firstContent = firstRows.map((r) => r.id + ':' + String(r.content || '')).sort().join('\n')
  assert.ok(firstCount >= 1, `automatic ingestion expected after first Read, got ${firstCount}`)

  fs.rmSync(path.join(dir, 'MAP.md'))

  const second = await executeBuiltinTool(db, ctx, 'Read', { file_path: 'MAP.md' }, io)
  assert.equal(second.is_error, true, 'duplicate read must still be rejected')
  assert.equal(second.content, '[harness] already read: MAP.md', 'result must be harness rejection, not a filesystem error')

  const secondRows = db.prepare(`SELECT id, content, entities_json, title FROM memories WHERE session_id = ?`).all(sid)
    .filter((r) => `${r.entities_json || ''} ${r.content || ''} ${r.title || ''}`.includes('MAP.md'))
  const secondIds = secondRows.map((r) => r.id).sort()
  const secondCount = secondRows.length
  const secondContent = secondRows.map((r) => r.id + ':' + String(r.content || '')).sort().join('\n')

  assert.deepEqual(secondIds, firstIds, 'memory IDs must not change on duplicate read')
  assert.equal(secondCount, firstCount, 'memory count must not change on duplicate read')
  assert.equal(secondContent, firstContent, 'memory content must not change on duplicate read')

  closeStore(dbPath)
  fs.rmSync(dir, { recursive: true, force: true })
})

async function withTimeout(promise, ms, label) {
  let timer
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms)
      }),
    ])
  } finally {
    clearTimeout(timer)
  }
}

await test('IJ-3: sufficient graph bypasses disk tools on explore turn (graph-first)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ij3-'))
  const repo = path.join(dir, 'repo')
  fs.mkdirSync(repo, { recursive: true })
  fs.mkdirSync(path.join(repo, 'docs'), { recursive: true })
  fs.writeFileSync(path.join(repo, 'docs', 'MAP.md'), '# MAP\nhealth router: src/health.mjs\n', 'utf8')
  fs.writeFileSync(path.join(repo, 'MAP.md'), '# MAP\nhealth router: src/health.mjs\n', 'utf8')

  const dbPath = path.join(dir, 't.db')
  const db = openStore(dbPath)
  const cid = 'c-ij3'
  const sid = 's-ij3'
  db.prepare(`INSERT INTO conversations(id, project_dir, phase) VALUES (?,?,?)`).run(cid, repo, 'idle')
  db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES (?,?)`).run(sid, cid)

  await ingestObservation(db, {
    sessionId: sid,
    conversationId: cid,
    title: 'Health endpoint map',
    text: 'Health check endpoint lives in src/health.mjs; MAP lists router bindings for asobacorp health service.',
    filePaths: ['docs/MAP.md', 'src/health.mjs'],
    provenance: 'explore_seed',
    layaOpts: { timeoutMs: 50 },
  })

  const prior = await retrieveEvidence(db, 'Review health check endpoint (#37)', {
    sessionId: sid,
    conversationId: cid,
    layaOpts: { timeoutMs: 50 },
  })
  assert.equal(prior.stoppedReason, 'sufficient', 'precondition: graph must report sufficiency')
  const seedEvidenceText = prior.evidence.map((e) => `- ${e.title}: ${String(e.content || '').slice(0, 300)}`).join('\n')
  const layaDecision = await assessEvidence(`Query: Review health check endpoint (#37)\n\nEvidence:\n${seedEvidenceText}`, { timeoutMs: 50 })
  assert.ok(layaDecision.sufficient >= 0.90, `precondition: Laya sufficiency must be ≥0.90, got ${layaDecision.sufficient}`)

  const mock = await startMockLlmServer()
  mock.queueResponse(makeOpenAiToolCallChunks('Read', { file_path: 'MAP.md' }))
  mock.queueResponse(makeOpenAiTextChunks('Exploration complete.'))

  let readAttempts = 0
  const autoIo = {
    ask: async () => 'y',
    println: () => {},
    write: () => {},
    onToolStart: (name, input) => {
      if (name === 'Read') readAttempts += 1
    },
    onToolResult: () => {},
  }
  const rt = {
    sessionId: sid,
    conversationId: cid,
    cwd: repo,
    runtimeDbPath: dbPath,
    settings: {
      permissions: { defaultMode: 'default' },
      model_config: {
        provider: 'openai_compatible',
        custom_model_name: 'beam:cloud',
        base_url: mock.baseUrl,
        api_key: 'ollama',
      },
    },
  }
  try {
    await withTimeout(runUserTurn(db, rt, 'Review health check endpoint (#37)', autoIo), 45000, 'IJ-3 runUserTurn')

    assert.equal(
      readAttempts,
      0,
      `IJ-3: sufficient graph must bypass disk Reads (graph-first); got ${readAttempts} Read starts`
    )
    const phase = getPhase(db, cid)
    assert.ok(
      phase !== 'explore' && phase !== 'idle',
      `IJ-3: must hand off out of explore/idle after graph-first, got ${phase}`
    )

    const negCid = 'c-ij3-neg'
    const negSid = 's-ij3-neg'
    db.prepare(`INSERT INTO conversations(id, project_dir, phase) VALUES (?,?,?)`).run(negCid, repo, 'explore')
    db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES (?,?)`).run(negSid, negCid)
    const negCtx = { cwd: repo, conversationId: negCid, sessionId: negSid, settings: {} }
    const negResult = await executeBuiltinTool(db, negCtx, 'Read', { file_path: 'MAP.md' }, autoIo)
    assert.equal(negResult.is_error, false, 'negative control: without sufficient evidence, canonical Read must remain possible')
  } finally {
    if (mock) await mock.close();
    closeStore(dbPath);
    fs.rmSync(dir, { recursive: true, force: true });
  }
})

await test('IJ-4: request 21 is blocked; forced saturation persists evidence and hands off to diagnose', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ij4-'))
  const repo = path.join(dir, 'repo')
  fs.mkdirSync(repo, { recursive: true })
  fs.writeFileSync(path.join(repo, 'MAP.md'), '# MAP\nrouter: src/index.mjs\n', 'utf8')
  const dbPath = path.join(dir, 't.db')
  const db = openStore(dbPath)
  const cid = 'c-ij4'
  const sid = 's-ij4'
  db.prepare(`INSERT INTO conversations(id, project_dir, phase) VALUES (?,?,?)`).run(cid, repo, 'idle')
  db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES (?, ?)`).run(sid, cid)

  const mock = await startMockLlmServer()
  try {
    assert.equal(
      getPinnedContextBlocks(db, sid).length,
      0,
      'IJ-4 precondition: no pinned explore digest before the run'
    )
    assert.equal(
      db.prepare(`SELECT COUNT(*) AS n FROM events WHERE conversation_id = ? AND event_type = 'saturation'`).get(cid).n,
      0,
      'IJ-4 precondition: no saturation event before the run'
    )

    // No model reply says "Exploration complete." during exploration. Each
    // response asks for another Read, so request 21 would be necessary to
    // continue normally. The production request budget must stop it instead.
    const EXPLORE_LIMIT = 20
    for (let i = 0; i < EXPLORE_LIMIT; i++) {
      mock.queueResponse(makeOpenAiToolCallChunks('Read', { file_path: 'MAP.md' }))
    }
    // The explore gate may request a file summary AFTER saturation; this reply
    // is for that downstream summarization, not a 21st explore-phase request.
    mock.queueResponse(makeOpenAiTextChunks('MAP.md identifies src/index.mjs as the router.'))

    let saturationModelRequests = null
    let saturationPhase = null
    let saturationNotice = null
    let diagnoseEntered = false
    const reachedHandoff = new Error('IJ-4: observed completed explore -> diagnose handoff')
    const autoIo = {
      ask: async () => 'y',
      println: (message) => {
        const line = String(message || '')
        if (/\[explore\].*Saturation: request budget exhausted/i.test(line)) {
          saturationModelRequests = mock.requestCount
          saturationPhase = getPhase(db, cid)
          saturationNotice = line
        }
        if (/Entering diagnose phase\./.test(line)) {
          diagnoseEntered = true
          // End this scenario at the actual handoff. Continuing would enter
          // unrelated diagnose/issue/planning gates, which IJ-4 does not test.
          throw reachedHandoff
        }
      },
      write: () => {},
      onToolStart: () => {},
      onToolResult: () => {},
    }
    const rt = {
      sessionId: sid,
      conversationId: cid,
      cwd: repo,
      runtimeDbPath: dbPath,
      settings: {
        permissions: { defaultMode: 'default' },
        model_config: {
          provider: 'openai_compatible',
          custom_model_name: 'beam:cloud',
          base_url: mock.baseUrl,
          api_key: 'ollama',
        },
      },
    }

    await assert.rejects(
      withTimeout(runUserTurn(db, rt, 'Review health check endpoint (#37)', autoIo), 45000, 'IJ-4 runUserTurn'),
      (error) => error === reachedHandoff,
      'IJ-4 must reach the production explore -> diagnose handoff before stopping the scenario'
    )

    assert.equal(saturationPhase, 'explore', 'saturation must occur while still in explore')
    assert.equal(
      saturationModelRequests,
      EXPLORE_LIMIT,
      `IJ-4: precisely ${EXPLORE_LIMIT} model requests must occur before explore blocks request ${EXPLORE_LIMIT + 1}`
    )
    assert.match(saturationNotice || '', /request budget exhausted at 20 upstream requests/i)
    assert.equal(diagnoseEntered, true, 'explore must hand off to diagnose after saturation')
    assert.equal(getPhase(db, cid), 'diagnose', 'handoff must persist diagnose as the next phase')

    const budgetEvents = db.prepare(`
      SELECT event_type, detail FROM events
      WHERE conversation_id = ? AND event_type IN ('saturation', 'explore_request_budget_exhausted')
      ORDER BY id
    `).all(cid)
    const saturated = budgetEvents.filter((event) => event.event_type === 'saturation')
    const exhausted = budgetEvents.filter((event) => event.event_type === 'explore_request_budget_exhausted')
    assert.equal(saturated.length, 1, 'production must persist exactly one saturation event')
    assert.equal(exhausted.length, 1, 'production must persist the explicit request-budget exhaustion event')

    const detail = JSON.parse(saturated[0].detail)
    assert.equal(detail.reason, 'explore_request_budget_exhausted')
    assert.equal(detail.limit, EXPLORE_LIMIT)
    assert.equal(detail.blockingRequest, EXPLORE_LIMIT + 1)
    const exhaustedDetail = JSON.parse(exhausted[0].detail)
    assert.equal(exhaustedDetail.limit, EXPLORE_LIMIT)
    assert.equal(exhaustedDetail.blockingRequest, EXPLORE_LIMIT + 1)

    const pinned = getPinnedContextBlocks(db, sid)
    const digestEntry = pinned.find((entry) => entry.key === 'explore_candidates_snapshot')
    assert.ok(digestEntry, 'saturation handoff must automatically persist explore_candidates_snapshot')
    const digestText = digestEntry.content ?? digestEntry.value ?? ''
    assert.match(String(digestText), /MAP\.md/, 'pinned digest must identify the file actually explored')
    assert.equal(digestEntry.session_id, sid, 'pinned digest must belong to the test session')
  } finally {
    try { await mock.close() } finally {
      closeStore(dbPath)
      fs.rmSync(dir, { recursive: true, force: true })
    }
  }
})

await test('IJ-CTRL: upsertPinnedContext round-trip (module contract)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ijc-'))
  const dbPath = path.join(dir, 't.db')
  const db = openStore(dbPath)
  db.prepare(`INSERT INTO conversations(id, project_dir) VALUES ('c','/tmp')`).run()
  db.prepare(`INSERT INTO sessions(session_id, conversation_id) VALUES ('s','c')`).run()
  upsertPinnedContext(db, 's', 'explore_candidates_snapshot', 'MAP.md → src/index.mjs')
  const blocks = getPinnedContextBlocks(db, 's')
  assert.equal(blocks.length, 1)
  assert.equal(blocks[0].key, 'explore_candidates_snapshot')
  closeStore(dbPath)
  fs.rmSync(dir, { recursive: true, force: true })
})

clearLayaPredictOverride()
console.log(`\n${passed} passed, ${failed} failed`)
if (failed > 0) process.exitCode = 1
